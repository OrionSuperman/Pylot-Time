from system.db.db_init import init_db

def initialize_db(app):
    init_db(app)
